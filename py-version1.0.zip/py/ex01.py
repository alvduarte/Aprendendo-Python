# Um script que leia o nome de uma pessoa e mostre uma mensagem de boas-vindas de acordo com o valor digitado

nome = input('Qual é o seu nome? :) ')

print('Seja bem vindo(a) ', nome, '!! :D')
