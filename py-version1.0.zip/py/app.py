print('Olá, Mundo!')  # Escreve Texto

print(7+4)  # Faz Cálculo

print('7'+'4')  # Escreve 2 textos juntos

nome1 = 'Guanabara'
idade1 = '25'
peso1 = '75.8'

print(nome1, idade1, peso1)  # Mostra as variavéis

nome2 = input('Qual é o seu nome? ')
idade2 = input('Qual é sua idade? ')
peso2 = input('Qual é o seu peso? ')

print(nome2, idade2, peso2)  # Mostra as variavéis que eu preenchi
