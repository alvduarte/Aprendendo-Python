# Um script que leia um número e mostre o seu dobro, triplo e raiz quadrada.
n1= int(input('Um número: '))
d = n1*2
t = n1*3

print('O dobro de {} é {} e o triplo é {}'.format(n1,d,t))

