# Um script que leia as duas notas de um aluno, calcule e mostre a sua média.

n1=float(input('nota 1: '))
n2=float(input('nota 2: '))

media=(n1+n2)/2

print('a média é {}'.format(media))