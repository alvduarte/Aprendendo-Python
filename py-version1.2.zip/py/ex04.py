# Um script que leia dois números e mostre a soma entre eles

n1 = int(input('Digite um número: '))
n2 = int(input('Digite outro: '))
s = n1+n2
print('a soma entre {} e {} dá {}'.format(n1, n2, s))
