# Utilizando módulos
import math
num = int(input('Digite um número:'))
raiz = math.sqrt(num)

print('A raiz de {} é igual a {:.2f}'.format(num, raiz))
