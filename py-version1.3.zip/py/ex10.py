# Um script que leia um número inteiro qualquer e mostra na tela a sua tabuada.

n1 = int(input('Quer saber a tabuada de qual número? '))

x1 = n1 * 1
x2 = n1 * 2
x3 = n1 * 3
x4 = n1 * 4
x5 = n1 * 5
x6 = n1 * 6
x7 = n1 * 7
x8 = n1 * 8
x9 = n1 * 9

print('A tabuada do {} é '.format(n1))
print('1 * {} é {}'.format(n1,x1))
print('2 * {} é {}'.format(n1,x2))
print('3 * {} é {}'.format(n1,x3))
print('4 * {} é {}'.format(n1,x4))
print('5 * {} é {}'.format(n1,x5))
print('6 * {} é {}'.format(n1,x6))
print('7 * {} é {}'.format(n1,x7))
print('8 * {} é {}'.format(n1,x8))
print('9 * {} é {}'.format(n1,x9))