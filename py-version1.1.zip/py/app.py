n1 = int(input('Digite um valor: '))
n2 = int(input('Digite outro: '))
s = n1 + n2
# print('A soma entre', n1, 'e', n2, 'vale', s)
print('A soma entre {} e {} vale {}'.format(n1, n2, s))

n = input('digite algo para verificar se é númerico ')
print(n.isnumeric())

na = input('digite algo para verificar se é alfabético ')
print(na.isalpha())

nam = input('digite algo para verificar se é alfanúmerico ')
print(nam.isalnum())