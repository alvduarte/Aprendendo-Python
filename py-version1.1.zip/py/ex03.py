# Um script que leia dois números e tente mostrar a soma deles

n1 = int(input('Primeiro número '))
n2 = int(input('Segundo número '))

print('A soma é ', n1+n2)
